﻿namespace $safeprojectname$.Resources
{
    public static class Constants
    {
        public static string ConnectionName = "DefaultConnection";
        public static string CorsName = "CodeiziCors";
    }
}