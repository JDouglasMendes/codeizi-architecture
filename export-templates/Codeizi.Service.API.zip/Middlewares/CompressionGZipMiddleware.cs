﻿using Microsoft.AspNetCore.Builder;

namespace $safeprojectname$.Middlewares
{
    public sealed class CompressionGZipMiddleware
    {
        public static void Configure(IApplicationBuilder app)
            => app.UseResponseCompression();
    }
}