﻿using Microsoft.Extensions.DependencyInjection;

namespace $safeprojectname$.Setups
{
    public static class JsonExtensions
    {
        public static IServiceCollection AddControllerAndJsonOptions(
            this IServiceCollection services)
        {
            services.AddControllers().AddJsonOptions(options =>
            {
                options.JsonSerializerOptions.IgnoreNullValues = true;
                options.JsonSerializerOptions.WriteIndented = false;
                options.JsonSerializerOptions.AllowTrailingCommas = false;
            });
            return services;
        }
    }
}