﻿using Codeizi.DI.AspNetCore;
using Microsoft.Extensions.DependencyInjection;

namespace $safeprojectname$.Setups
{
    public static class DependenceInjectionExtensions
    {
        public static IServiceCollection AddCodeiziDI(this IServiceCollection services)
            => services.AddInjectables(typeof(Startup));
    }
}