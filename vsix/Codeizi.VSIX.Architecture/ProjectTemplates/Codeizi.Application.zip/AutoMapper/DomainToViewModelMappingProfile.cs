﻿using AutoMapper;

namespace $safeprojectname$.AutoMapper
{
    public class DomainToViewModelMappingProfile : Profile
    {
    }
}