﻿using AutoMapper;

namespace $safeprojectname$.AutoMapper
{
    public class ViewModelToDomainMappingProfile : Profile
    {
    }
}